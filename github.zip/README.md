# Trendyol Bot APK

Trendyol'da otomatik ürün arama ve gezinme botu.

## Özellikler

- Ürün adı veya Trendyol linki ile arama
- Otomatik sayfa gezinme (6 saniye)
- Uçak modu ile ağ sıfırlama
- Döngü sayısı belirleme
- Accessibility Service ile uçak modu kontrolü

## Kurulum

1. Android Studio'da projeyi açın
2. APK'yı derleyin ve cihaza yükleyin
3. Accessibility ayarlarından "Trendyol Bot" servisini etkinleştirin
4. Uygulamayı açın ve kullanmaya başlayın

## Kullanım

1. Ürün adı veya Trendyol linki girin
2. Döngü sayısını belirleyin
3. "Accessibility Ayarları" butonuna tıklayıp servisi etkinleştirin
4. "Başlat" butonuna tıklayın

## Gereksinimler

- Android 7.0+ (API 24+)
- Accessibility Service izni
- İnternet bağlantısı

## Uyarı

Bu uygulama eğitim amaçlıdır. Trendyol'un kullanım şartlarını ihlal edebilir.