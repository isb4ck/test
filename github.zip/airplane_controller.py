#!/usr/bin/env python3
import subprocess
import socket
import time
import threading
import requests
import xml.etree.ElementTree as ET

class AirplaneController:
    def __init__(self):
        self.device_ip = None
        self.is_monitoring = False
        self.ping_site = "https://example.com"
        self.ping_title = "Bot Traffic"
        
    def find_device(self):
        """ADB ile bağlı cihazı bul"""
        try:
            result = subprocess.run(['adb', 'devices'], capture_output=True, text=True)
            lines = result.stdout.strip().split('\n')[1:]
            
            for line in lines:
                if 'device' in line:
                    device_id = line.split()[0]
                    print(f"✅ Cihaz bulundu: {device_id}")
                    return device_id
            
            print("❌ Hiç cihaz bulunamadı")
            return None
        except Exception as e:
            print(f"❌ ADB hatası: {e}")
            return None
    
    def setup_port_forward(self, device_id):
        """Port forwarding kur"""
        try:
            subprocess.run(['adb', '-s', device_id, 'forward', 'tcp:8888', 'tcp:8888'], 
                         capture_output=True)
            print("✅ Port forwarding kuruldu (8888)")
            return True
        except Exception as e:
            print(f"❌ Port forwarding hatası: {e}")
            return False
    
    def toggle_airplane_mode(self, device_id, enable):
        """Uçak modunu aç/kapat"""
        try:
            # Uçak modu ayarını değiştir
            mode_value = "1" if enable else "0"
            cmd1 = ['adb', '-s', device_id, 'shell', 'settings', 'put', 'global', 'airplane_mode_on', mode_value]
            subprocess.run(cmd1, capture_output=True)
            
            # Broadcast gönder
            cmd2 = ['adb', '-s', device_id, 'shell', 'am', 'broadcast', 
                   '-a', 'android.intent.action.AIRPLANE_MODE', 
                   '--ez', 'state', str(enable).lower()]
            subprocess.run(cmd2, capture_output=True)
            
            action = "AÇILDI" if enable else "KAPANDI"
            print(f"✅ Uçak modu {action}")
            return True
            
        except Exception as e:
            print(f"❌ Uçak modu hatası: {e}")
            return False
    
    def send_ping(self):
        """Ping gönder"""
        try:
            xml_request = f'''<?xml version="1.0" encoding="UTF-8"?>
<methodCall>
<methodName>weblogUpdates.ping</methodName>
<params>
<param><value><string>{self.ping_title}</string></value></param>
<param><value><string>{self.ping_site}</string></value></param>
</params>
</methodCall>'''
            
            response = requests.post(
                'https://rpc.pingomatic.com/',
                data=xml_request,
                headers={'Content-Type': 'text/xml; charset=UTF-8'},
                timeout=10
            )
            
            if response.status_code == 200:
                print("📡 Ping BAŞARILI")
            else:
                print("⚠️ Ping başarısız ama devam")
                
        except Exception as e:
            print(f"⚠️ Ping hatası ama devam: {e}")
    
    def send_confirmation(self, command):
        """Telefona onay gönder ve ping at"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect(('localhost', 8888))
            sock.send(f"{command}\n".encode())
            sock.close()
            print(f"✅ Onay gönderildi: {command}")
            
            # Her işlem bitiminde ping at
            print("📡 Ping gönderiliyor...")
            self.send_ping()
            
        except Exception as e:
            print(f"❌ Onay gönderme hatası: {e}")
    
    def monitor_requests(self, device_id):
        """Telefon isteklerini dinle"""
        self.is_monitoring = True
        print("🎧 Telefon istekleri dinleniyor...")
        
        while self.is_monitoring:
            try:
                # Logcat'ten komutları dinle
                process = subprocess.Popen(
                    ['adb', '-s', device_id, 'logcat', '-s', 'TrendyolBot'],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
                
                for line in process.stdout:
                    if not self.is_monitoring:
                        break
                        
                    if "AIRPLANE_REQUEST_ON" in line:
                        print("📱 Telefon uçak modu AÇMA isteği gönderdi")
                        if self.toggle_airplane_mode(device_id, True):
                            time.sleep(1)
                            self.send_confirmation("AIRPLANE_ON")
                    
                    elif "AIRPLANE_REQUEST_OFF" in line:
                        print("📱 Telefon uçak modu KAPATMA isteği gönderdi")
                        if self.toggle_airplane_mode(device_id, False):
                            time.sleep(1)
                            self.send_confirmation("AIRPLANE_OFF")
                
                process.terminate()
                
            except Exception as e:
                print(f"❌ Monitoring hatası: {e}")
                time.sleep(2)
    
    def configure_ping(self, site=None, title=None):
        """Ping ayarlarını yapılandır"""
        if site:
            self.ping_site = site
        if title:
            self.ping_title = title
        print(f"📡 Ping ayarları: {self.ping_title} -> {self.ping_site}")
    
    def start(self):
        """Kontrolcüyü başlat"""
        print("🚀 Trafik Bot - Bilgisayar Kontrolcüsü")
        print("=" * 50)
        
        # Ping ayarlarını sor
        site_input = input("🌐 Ping sitesi (Enter=varsayılan): ").strip()
        title_input = input("📝 Ping başlığı (Enter=varsayılan): ").strip()
        
        if site_input:
            self.ping_site = site_input
        if title_input:
            self.ping_title = title_input
            
        print(f"📡 Ping: {self.ping_title} -> {self.ping_site}")
        print("=" * 50)
        
        # Cihazı bul
        device_id = self.find_device()
        if not device_id:
            print("❌ Önce telefonu USB ile bağlayın ve 'adb devices' çalıştırın")
            return
        
        # Port forwarding kur
        if not self.setup_port_forward(device_id):
            return
        
        print("\n✅ Sistem hazır!")
        print("📱 Telefonda uygulamayı başlatabilirsiniz")
        print("🔄 Uçak modu komutları otomatik işlenecek")
        print("📡 Her işlem sonunda ping gönderilecek")
        print("❌ Durdurmak için Ctrl+C basın\n")
        
        try:
            # Monitoring başlat
            self.monitor_requests(device_id)
        except KeyboardInterrupt:
            print("\n🛑 Kontrolcü durduruldu")
            self.is_monitoring = False

if __name__ == "__main__":
    controller = AirplaneController()
    controller.start()