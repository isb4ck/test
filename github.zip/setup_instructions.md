# Trendyol Bot - Bilgisayar Kontrol Sistemi

## Android 14 Uyumlu Uçak Modu Kontrolü

### 🖥️ Bilgisayar Kurulumu

1. **Python Kurulumu**
   ```bash
   # Python 3.7+ gerekli
   python --version
   ```

2. **ADB Kurulumu**
   ```bash
   # Windows için
   # Android SDK Platform Tools indirin
   # PATH'e ekleyin
   
   # Test edin
   adb version
   ```

3. **Script Çalıştırma**
   ```bash
   cd telefonapk
   python airplane_controller.py
   ```

### 📱 Telefon Kurulumu

1. **Geliştirici Seçenekleri**
   - Ayarlar > Telefon Hakkında
   - Yapı Numarası'na 7 kez tıkla

2. **USB Hata Ayıklama**
   - Geliştirici Seçenekleri > USB Hata Ayıklama ✅

3. **USB Bağlantısı**
   - Telefonu USB ile bilgisayara bağla
   - "Bu bilgisayara güven" onayı ver

### 🚀 Kullanım

1. **Bilgisayarda:**
   ```bash
   python airplane_controller.py
   ```
   
2. **Telefonda:**
   - APK'yı aç
   - Trendyol ürün linki gir
   - Döngü sayısı belirle
   - "Başlat" butonuna bas

### 🔄 Çalışma Mantığı

1. Telefon bot çalışır ve sayfada gezinir
2. 6 saniye sonra bilgisayara "uçak modu aç" komutu gönderir
3. Python script ADB ile uçak modunu açar
4. 4 saniye bekler
5. Python script ADB ile uçak modunu kapatır
6. Telefon onay alır ve yeni döngüye başlar

### ⚡ Avantajlar

- ✅ Android 14'te çalışır
- ✅ %100 gerçek uçak modu
- ✅ Sistem kısıtlamalarını aşar
- ✅ Güvenilir ağ kesintisi
- ✅ Otomatik kontrol

### 🛠️ Sorun Giderme

**"Cihaz bulunamadı" hatası:**
```bash
adb devices
# Cihaz listesini kontrol et
```

**"İzin reddedildi" hatası:**
```bash
adb kill-server
adb start-server
# ADB'yi yeniden başlat
```

**Port hatası:**
- Başka uygulama 8888 portunu kullanıyor olabilir
- Bilgisayarı yeniden başlatın